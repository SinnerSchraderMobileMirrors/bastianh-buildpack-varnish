#define VMOD_ABI_Version "Varnish 4.1.3 5e3b6d2"
